window.onload = function () {
	//bandeauResize();
	//Event.observe(window, "resize", bandeauResize);
}

