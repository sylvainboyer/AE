				<div id="tract">
					<a href="pdf/tract-eceh_2017.pdf" target="_blank">
						<img alt="Affiche ECEH" id="affiche" src="gfx/affiche_2017-web.jpg" /></a>
					<!--<p class="affiche">
						<a href="pdf/affiche-eceh.pdf">téléchargez l'affiche (pdf)
							<img alt="pdf" id="affpdf" src="gfx/icn-acrobat.jpg" /></a>
					</p>
					<a href="pdf/tract-eceh.pdf">
						<img alt="Tract ECEH" id="tract" src="gfx/tract.png" /></a>
					<p>-->
					<a href="pdf/tract-eceh_2017.pdf" target="_blank">Le tract 2017 (pdf)<img alt="pdf" class="pdf" src="gfx/icn-acrobat.gif" /></a>
					<!--</p>-->
				</div>

				<div id="carte" class="carte_th">
					<!--<a href="pdf/tract-eceh_2015.pdf">
						<img alt="Affiche ECEH" id="affiche" src="gfx/affiche_2015.png" /></a>
					<a href="pdf/tract-eceh_2015.pdf">Le tract 2015 (pdf)<img alt="pdf" class="pdf" src="gfx/icn-acrobat.gif" /></a>-->
					<img alt="Carte" id="carte_img" src="gfx/map/carte2017_th.gif" />
					<p id="titre_carte_th">La carte</p>
				</div>
