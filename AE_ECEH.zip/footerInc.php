	<div class="footerinc">
		<p class="footer">Alter’énergies ~ 8 allée des Rossignols − 37170 Chambray-lès-Tours ~ infos@alterenergies.org</p>
		<p class="footer">Site réalisé par Alter'énergies ~
<!--<a target="_blank" href="/feed.php" title="Recent changes RSS feed">
	<img src="gfx/button-rss.png" width="80" height="15" alt="Recent changes RSS feed />
</a>-->
			<a href="http://www.php.net/" title="Powered by PHP">
				<img src="gfx/button-php.gif" alt="Powered by PHP" height="15" width="80" /></a>

			<a href="http://validator.w3.org/check/referer" title="Valid XHTML 1.0">
				<img src="gfx/button-xhtml.png" alt="Valid XHTML 1.0" height="15" width="80" /></a>

			<a href="http://jigsaw.w3.org/css-validator/check/referer" title="Valid CSS 3">
				<img src="gfx/button-css.png" alt="Valid CSS" height="15" width="80" /></a>
		</p>
<!--
The following stuff in HTML comments declares a Creative Commons
License - remove this if you don\'t want this license for your Wiki

<rdf:RDF xmlns="http://web.resource.org/cc/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
<Work rdf:about="">
   <dc:type rdf:resource="http://purl.org/dc/dcmitype/Text" />
   <license rdf:resource="http://creativecommons.org/licenses/by-nc-sa/2.0/" />
</Work>

<License rdf:about="http://creativecommons.org/licenses/by-nc-sa/2.0/">
   <permits rdf:resource="http://web.resource.org/cc/Reproduction" />
   <permits rdf:resource="http://web.resource.org/cc/Distribution" />
   <requires rdf:resource="http://web.resource.org/cc/Notice" />
   <requires rdf:resource="http://web.resource.org/cc/Attribution" />
   <prohibits rdf:resource="http://web.resource.org/cc/CommercialUse" />
   <permits rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
   <requires rdf:resource="http://web.resource.org/cc/ShareAlike" />
</License>

</rdf:RDF>

-->
	</div>
	<div class="no">
		<!--<img src="gfx/indexer.gif" alt="" height="1" width="1" />
		<a href="http://validator.progysm.com/check.php?uri=referer">Validation</a>-->
	</div>
