				<div id="partenaires">
					<h1><a name="nos_partenaires" id="nos_partenaires">Nos partenaires :</a></h1>
					<!--<a href="http://www.ademe.fr/" class="media" title="partenaire ADEME">-->
						<img src="gfx/logo_EER.png" id="eer" class="mediacenter" title="EER" alt="logo EER" /><!--</a>-->
					<!--<a href="http://www.regioncentre-valdeloire.fr/accueil.html" class="media" title="partenaire région">-->
					<!--<img src="gfx/logo_STA.jpg" id="sta" class="mediacenter" title="STA" alt="logo STA" />--><!--</a>-->
				</div>

				<div id="alterenergies">
				  <p>
					  <a href="http://www.alterenergies.org/doku.php?id=alterenergies:projet:alterenergies" class="media" title="alterenergies:projet:alterenergies">
						<img id="logo-alterenergies" src="gfx/logo_ae.jpg" class="media" title="Alter'énergies" alt="Alter'énergies" /></a>
					  <br />
					  <a href="http://www.alterenergies.org/doku.php?id=alterenergies:projet:alterenergies" class="wikilink1" title="alterenergies:projet:alterenergies">L'association</a>
				  </p>
				</div>

				<div id="histo">
					<h1>Historique :</h1>
					<a href="pdf/tract-eceh_2016.pdf">
						<img alt="Affiche 2016" id="affiche2016" src="gfx/affiche_2016.png" title="Afficher le tract 2016" class="affiche_histo" />
					</a>
					<a href="pdf/tract-eceh_2016.pdf">tract 2016 (pdf)
						<img alt="pdf" class="pdf_h" src="gfx/icn-acrobat.gif" />
					</a>
					<div class="histo-sep">&nbsp;</div>
					<a href="pdf/tract-eceh_2015.pdf">
						<img alt="Affiche 2015" id="affiche2015" src="gfx/affiche_2015.png" title="Afficher le tract 2015" class="affiche_histo" />
					</a>
					<a href="pdf/tract-eceh_2015.pdf">tract 2015 (pdf)
						<img alt="pdf" class="pdf_h" src="gfx/icn-acrobat.gif" />
					</a>
					<div class="histo-sep">&nbsp;</div>
					<a href="pdf/tract-eceh_2014.pdf">
						<img alt="Affiche 2014" id="affiche2014" src="gfx/affiche_2014.jpg" title="Afficher le tract 2014" class="affiche_histo" />
					</a>
					<a href="pdf/tract-eceh_2014.pdf">tract 2014 (pdf)
						<img alt="pdf" class="pdf_h" src="gfx/icn-acrobat.gif" />
					</a>
					<div class="histo-sep">&nbsp;</div>
					<a href="pdf/tract-eceh_2013.pdf">
						<img alt="Affiche 2013" id="affiche2013" src="gfx/affiche_2013.png" title="Afficher le tract 2013" class="affiche_histo" />
					</a>
					<a href="pdf/tract-eceh_2013.pdf">tract 2013 (pdf)
						<img alt="pdf" class="pdf_h" src="gfx/icn-acrobat.gif" />
					</a>
					<div class="histo-sep">&nbsp;</div>
					<a href="pdf/tract-eceh_2012.pdf">
						<img alt="Affiche 2012" id="affiche2012" src="gfx/affiche_2012.png" title="Afficher le tract 2012" class="affiche_histo" />
					</a>
					<a href="pdf/tract-eceh_2012.pdf">tract 2012 (pdf)
						<img alt="pdf" class="pdf_h" src="gfx/icn-acrobat.gif" />
					</a>
					<div class="histo-sep">&nbsp;</div>
					<a href="pdf/tract-eceh_2011.pdf">
						<img alt="Affiche 2011" id="affiche2011" src="gfx/affiche_2011.png" title="Afficher le tract 2011" class="affiche_histo" />
					</a>
					<a href="pdf/tract-eceh_2011.pdf">tract 2011 (pdf)
						<img alt="pdf" class="pdf_h" src="gfx/icn-acrobat.gif" />
					</a>
				</div>
